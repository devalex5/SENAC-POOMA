package FolhaDePagamento;


public class Funcionario {
protected String nomeFuncionario;
protected String nomeDepartamento;
protected String funcao;
//
public Funcionario () {
this.nomeFuncionario="Joaquim Jose da silva Xavier";
this.nomeDepartamento="manutenção";
this.funcao="Ajudante geral";
}
}