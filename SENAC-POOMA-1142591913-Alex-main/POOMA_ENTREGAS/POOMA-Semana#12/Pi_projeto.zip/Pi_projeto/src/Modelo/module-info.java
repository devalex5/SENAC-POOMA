/**
 * 
 */
/**
 * @author alexandre.mzyassaka
 *
 */
module Pi_projeto {
	requires java.desktop;
	requires java.sql;
}